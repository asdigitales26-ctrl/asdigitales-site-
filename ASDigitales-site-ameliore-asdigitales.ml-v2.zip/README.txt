ASDIGITALES — VERSION AMÉLIORÉE

Pages : index.html, a-propos.html, formations.html, inscription.html, actualites.html, galerie.html, contact.html, 404.html
Ressources : style.css, script.js, logo.png, hero-academie.png
Domaine : asdigitales.ml
Email : asdigitales26@gmail.com
WhatsApp : (+223) 76 24 96 85

IMPORTANT : le formulaire est statique et ouvre la messagerie du visiteur (mailto). Il ne stocke pas les inscriptions. Pour une vraie base d’inscriptions, ajouter un service de formulaire ou un backend.

GitHub Pages : le fichier CNAME est inclus. Le fichier .htaccess n’est pas nécessaire sur GitHub Pages et n’est donc pas inclus dans cette version.
